tetsing tetsing tetsinng!!!!! why?
default login: something@email.com  Password: Password_1
session stores login
cookie is stored when remember me is checked
email is sent to user when sign up
email is sent to user when enter email in forget password page