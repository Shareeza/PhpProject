<?php


?>

<html>
<body>
<form action="index.php" method="post" Id="add_category_form">
<input type="text" name="categoryName"/>
<br/>
<input type="submit" value="Add Category"/>
</form>
</body>
</html>