
<?php
$category_id = filter_input(INPUT_POST, 'categoryId', FILTER_VALIDATE_INT);

?>


<html>
<body>
<form action="index.php" method="post" Id="update_category_form">
<input type="text" name="newCategoryType"/>
<br/>
<input type="submit" value="Update"/>
<input type="hidden" name="oldCategoryId"
                           value="<?php echo  $category_id; ?>">
</form>
</body>
</html>