<?php
$skinTypeId = filter_input(INPUT_POST, 'skinTypeId', FILTER_VALIDATE_INT);

//echo $skinTypeId;

?>


<html>
<body>
<form action="indexSkin.php" method="post" Id="update_skinType_form">
<input type="text" name="newSkinType"/>
<br/>
<input type="submit" value="Update"/>
<input type="hidden" name="oldSkinTypeId"
                           value="<?php echo  $skinTypeId; ?>">
</form>
</body>
</html>