<?php

require_once('../model/CategoryDB.php');

$delete = filter_input(INPUT_POST, 'categoryId', 
            FILTER_VALIDATE_INT);

header("Location:index.php");

		
			
CategoryDB::deleteCategory($delete);



?>