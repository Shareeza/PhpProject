<html>
<body>
<form action="indexSkin.php" method="post" Id="add_skinType_form">
<input type="text" name="skinTypeName"/>
<br/>
<input type="submit" value="Add Skin Type"/>
</form>
</body>
</html>