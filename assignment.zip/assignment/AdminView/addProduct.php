<html>

<head>
<link href="country/dist/css/bootstrap-formhelpers.min.css" rel="stylesheet">
 <link href="country/dist/css/bootstrap-formhelpers.css" rel="stylesheet">
</head>

<html>
    <h1>Add Product</h1>
    <form action="productForm.php" method="post" id="add_product_form"  enctype='multipart/form-data'>
        <input type="hidden" name="action" value="add_product" />


        <label>Product Name:</label>
        <input type="text" name="productName">
        <br>
		
        <label>Ingredients:</label>
        <input type="text" name="ingredients">
        <br>

        <label>Country:</label>
        <select name="country" class="input-medium bfh-countries" data-country="US"></select>
        <br>
		
		<label>Images:</label>
        <input type="file" name="images" id="images">
        <br>


        <label>&nbsp;</label>
        <input type="submit" value="Add Product">
        <br>
    </form>
	<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
    <script src="country/js/google-code-prettify/prettify.js"></script>

    <script src="country/js/bootstrap-formhelpers-selectbox.js"></script>
    <script src="country/js/bootstrap-formhelpers-countries.en_US.js"></script>
    <script src="country/js/bootstrap-formhelpers-countries.js"></script>

	<script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
	</body>
	</html>