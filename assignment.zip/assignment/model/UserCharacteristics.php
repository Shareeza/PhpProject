<?php
class UserCharacteristics {
    private $hairType;
    private $skinTypeId;
	private $userId;
    private $skinTone;
	private $skinProblem;
	private $eyeColor;
	

    public function __construct($hairType, $skinTypeId, $userId, $skinTone, $skinProblem,$eyeColor) {
        $this->hairType  = $hairType;
		$this->skinTypeId   = $skinTypeId;
		$this->userId   = $userId;
        $this->skinTone = $skinTone;
		$this->password = $skinProblem;
		$this->eyeColor = $eyeColor;
		
    }

	public function getUserId() {
        return $this->userId;
    }

    public function setUserId($value) {
        $this->userId = $value;
    }
	
    public function getSkinTypeId() {
        return $this->skinTypeId;
    }

    public function setSkinTypeId($value) {
        $this->skinTypeId = $value;
    }

    public function getSkinTone() {
        return $this->skinTone;
    }

    public function setSkinTone($value) {
        $this->skinTone = $value;
    }
	
	
    public function getSkinType() {
        return $this->skinType;
    }

    public function setSkinType($value) {
        $this->skinType = $value;
    }
	
	public function getHairType() {
        return $this->hairType;
    }

    public function setHairType($value) {
        $this->hairType = $value;
    }
	
	public function getSkinProblem() {
        return $this->skinProblem;
    }

    public function setSkinProblem($value) {
        $this->skinProblem = $value;
    }
	
	public function getEyeColor() {
        return $this->eyeColor;
    }

    public function setEyeColor($value) {
        $this->eyeColor = $value;
    }
	
	
	
}
?>