<?php
require_once('database.php');

class UserLoginDB {

    public static function getUserLogin() {
        $db = DataBaseConnection::createDataBaseConnection();
        $query = 'SELECT * FROM userlogin
                  ';
        $statement = $db->prepare($query);
        $statement->execute();
        
        $loginDetails = array();
        foreach ($statement as $row) {
            $login = new UserLogin($row['loginId'], $row['roleID'],
                                     $row['userName'], $row['password'],$row['email']);
            $loginDetails[] = $login;
        }
        return $loginDetails;
    }

    public static function getUserLoginByRole($roleID) {
       $db = DataBaseConnection::createDataBaseConnection();
       $query = 'SELECT * FROM userlogin
                  WHERE roleID = :roleID';    
        $statement = $db->prepare($query);
        $statement->bindValue(':roleID', $roleID);
        $statement->execute();    
        $row = $statement->fetch();
        $statement->closeCursor();    
        $login = new UserLogin($row['loginId'], $row['roleID'],
                                     $row['userName'], $row['password'], $row['email']);
        return $login;
    }
	
	 public static function getUserLoginByUserID($loginId) {
       $db = DataBaseConnection::createDataBaseConnection();
       $query = 'SELECT * FROM userlogin
                  WHERE loginId = :loginId';    
        $statement = $db->prepare($query);
        $statement->bindValue(':loginId', $loginId);
        $statement->execute();    
        $row = $statement->fetch();
        $statement->closeCursor();    
        $login = new UserLogin($row['loginId'], $row['roleID'],
                                     $row['userName'], $row['password'], $row['email']);
        return $login;
    }
	
	
	
	
}
?>