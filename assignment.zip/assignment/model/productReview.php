<?php
class ProductReview {
    private $reviewId;
    private $userId;
	private $productId;
	private $reviewMessage;
	private $rating;
	

    public function __construct($reviewId, $userId, $productId,$reviewMessage, $rating) {
        $this->reviewId  = $reviewId;
		$this->userId   = $userId;
		$this->productId   = $productId;
		$this->reviewMessage = $reviewMessage;
		$this->rating= $rating;
		
    }

    public function getUserId() {
        return $this->userId;
    }

    public function setUserId($value) {
        $this->userId = $value;
    }

	
	public function getReviewId() {
        return $this->reviewId;
    }

    public function setReviewId($value) {
        $this->reviewId = $value;
    }
	
	
	public function getReviewMessage() {
        return $this->reviewMessage;
    }

    public function setReviewMessage($value) {
        $this->reviewMessage = $value;
    }
	
	public function getProductId() {
        return $this->productId;
    }

    public function setProductId($value) {
        $this->productId = $value;
    }
	
	
	public function getRating() {
        return $this->rating;
    }

    public function setRating($value) {
        $this->rating = $value;
    }
	
	
	
}
?>