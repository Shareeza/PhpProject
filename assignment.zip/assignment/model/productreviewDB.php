<?php
require_once('database.php');

class ProductReviewDB {

    public static function getProductReview() {
        $db = DataBaseConnection::createDataBaseConnection();
        $query = 'SELECT * FROM productreview
                  ';
        $statement = $db->prepare($query);
        $statement->execute();
        
        $reviews = array();
        foreach ($statement as $row) {
            $review = new ProductReview($row['reviewId'], $row['userId'],$row['productId'],
                                     $row['reviewMessage'], $row['rating']);
            $reviews[] = $review;
        }
        return $reviews;
    }

    public static function getProductReviewByUserId($userId) {
       $db = DataBaseConnection::createDataBaseConnection();
       $query = 'SELECT * FROM productreview
                  WHERE userId = :userId';    
        $statement = $db->prepare($query);
        $statement->bindValue(':userId', $userId);
        $statement->execute();    
        $row = $statement->fetch();
        $statement->closeCursor();    
        $review = new ProductReview($row['reviewId'], $row['userId'],$row['productId'],
                                     $row['reviewMessage'], $row['rating']);
        return $review;
    }
	
	 public static function getProductReviewByProductId($productId) {
       $db = DataBaseConnection::createDataBaseConnection();
       $query = 'SELECT * FROM productreview
                  WHERE productId = :productId';    
        $statement = $db->prepare($query);
        $statement->bindValue(':productId', $productId);
        $statement->execute();    
        $row = $statement->fetch();
        $statement->closeCursor();    
        $review = new ProductReview($row['reviewId'], $row['userId'],$row['productId'],
                                     $row['reviewMessage'], $row['rating']);
        return $review;
    }
	
	
	
	
}
?>