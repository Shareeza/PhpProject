<?php
require_once('database.php');

class UserCharacteristicsDB {

    public static function getUserCharacteristics() {
        $db = DataBaseConnection::createDataBaseConnection();
        $query = 'SELECT * FROM usercharacteristics
                  ';
        $statement = $db->prepare($query);
        $statement->execute();
        
        $userCharacteristics = array();
        foreach ($statement as $row) {
            $userChar = new UserCharacteristics($row['userId'], $row['skinTypeId'],$row['hairType'],
                                     $row['skinTone'], $row['skinProblem'],$row['eyeColor'] );
            $userCharacteristics[] = $userChar;
        }
        return $userCharacteristics;
    }

    public static function getUserCharacteristicsById($userId) {
       $db = DataBaseConnection::createDataBaseConnection();
       $query = 'SELECT * FROM usercharacteristics
                  WHERE userId = :userId';    
        $statement = $db->prepare($query);
        $statement->bindValue(':userId', $userId);
        $statement->execute();    
        $row = $statement->fetch();
        $statement->closeCursor();    
        $userCharc = new UserCharacteristics($row['userId'], $row['skinTypeId'],$row['hairType'],
                                     $row['skinTone'], $row['skinProblem'],$row['eyeColor'] );
        return $userChar;
    }
	
	
	
	
	
	
}
?>